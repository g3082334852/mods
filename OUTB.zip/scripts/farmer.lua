--------------------------------------------------------------------------
--[[ Farmer class definition ]]
--------------------------------------------------------------------------

return Class(function(self, inst)

--------------------------------------------------------------------------
--[[ Dependencies ]]
--------------------------------------------------------------------------

local Helper = require "helper"
local Parser = require "parser"
local tools = require "tools"
local os = require "os"

--------------------------------------------------------------------------
--[[ Constants ]]
--------------------------------------------------------------------------

local BOOK_ITEM = "book_silviculture"
local BOOK_RAW = "papyrus"
local BOOK_PACK = "gift"
local WRAP_ITEM = "giftwrap"
local CAVE_FUEL = "lightbulb"
local BARREN_ITEM = "spoiled_food"
local ICE_FUEL = "nitre"
local FOOD = "meatballs"
local FOOD_PRICE = 120
local NMT = "nightmare_timepiece"

local CONFIG_LIST = {
    general = {
        "range"
    },
    pick = {
        "grass",
        "sapling",
        "reeds",
		"monkeytail"
    }
}

local SELLITEMS = {
    "cutgrass",
    "twigs",
	"cutreeds"
}

--------------------------------------------------------------------------
--[[ Member variables ]]
--------------------------------------------------------------------------

--Public
self.inst = inst
self.name = "自动收集"
self.prefix = "farmer"
self.config = CONFIG_LIST
self.run = false

--Private
local _helper
local _parser
local _cfg
local _is_wicker
local _start_pos
local _start_time
local _report_time
local _mob
local _fuel
local _equip
local _crop
local _ice
local _items, _es
local _pack
local _weapon
local _nmt
local _coin
local _unpack
--新加
local _death
local _death_cost
local _reservecoin
local _credit
local _revive_record
local _is_death
local _report_time


--------------------------------------------------------------------------
--[[ Private event handlers ]]
--------------------------------------------------------------------------

--------------------------------------------------------------------------
--[[ Initialization ]]
--------------------------------------------------------------------------

_helper = Helper(inst)
_parser = Parser(inst)
_is_wicker = inst.prefab == "wickerbottom"


--------------------------------------------------------------------------
--[[ Private member functions ]]
--------------------------------------------------------------------------

local function RefreshItem()
    _items, _es = _helper:Items()
    return true
end

local function ShouldFuel()
    if not TheWorld.state.isnight then return end
    _equip = _helper:Equip("CAVE_fueled", 20)
    
    if _equip then
        return true
    end
end

local function ShouldAttack()--攻击
    local mobs = _helper:Find(nil, 16, {"_combat", "_health"}, {"FX", "NOCLICK", "DECOR", "INLIMBO", "wall"}, nil, nil, function(e)
        if e and e:IsValid() and
            not e.replica.health:IsDead() and
            _helper.combat:CanTarget(e) and
            e.replica.combat:GetTarget() == self.inst then
            return true
        end
    end)
    if mobs and #mobs > 0 then
        _mob = mobs[1]
        return true
    end
end

local function ShouldPick()
    local crops = _helper:Find(nil, _cfg.general.range, { "pickable" }, nil, nil, nil, function(e) return _cfg.pick[e.prefab] and e:GetDistanceSqToPoint(_start_pos:Get()) < _cfg.general.range * _cfg.general.range end)
    
    if #crops > 0 then
        _crop = crops[1]
        return true
    end
end

local function ShouldIce()
    if not TheWorld.state.issummer then return end
    local ices = _helper:Find(nil, 16, { "fueldepleted" }, nil, nil, "firesuppressor", function(e) return e:GetDistanceSqToPoint(_start_pos:Get()) < 256 end)
    
    if #ices > 0 then
        _ice = ices[1]
        return true
    end
end

local function ShouldSell()
    for _, v in ipairs(SELLITEMS) do
        if _items[v] then
            return true
        end
    end
end

local function ShouldBarren()
    local crops = _helper:Find(nil, _cfg.general.range, { "barren" }, nil, nil, nil, function(e) return _cfg.pick[e.prefab] and e:GetDistanceSqToPoint(_start_pos:Get()) < _cfg.general.range * _cfg.general.range end)
    
    if #crops > 0 then
        _crop = crops[1]
        return true
    end
end

local function ShouldPack()
    _pack = {}
    _helper:IterateInventory(function(e,i,c)
        if e and e.prefab == BOOK_RAW and tools.is_full(e) then
            table.insert(_pack, {item = e, slot = i, container = c})
        end
    end)
    
    return #_pack > 3
end

local function ShouldUnpack()
    _unpack = nil
    
    _helper:IterateInventory(function(e)
        if e and e.prefab == BOOK_PACK then
            local data = _parser:GetShowMeData(e, 3600, 3)
            if data and data.items then
                for i, v in ipairs(data.items) do
                    if v.prefab == BOOK_RAW then
                        _unpack = e
                        return true
                    end
                end
            end
        end
    end)
    
    return _unpack
end

local function DoSell(force)
    while self.run or force do
        _helper:IterateInventory(function(e)
            if e and e.prefab and table.contains(SELLITEMS, e.prefab) then
                _helper.inventory:ControllerUseItemOnItemFromInvTile(_nmt, e)
                Sleep(0.1)
            end
        end)
        
        if not ShouldSell() or ShouldAttack() then
            break
        end
        RefreshItem()
    end
end

--------------------------------------------------------------------------
--[[ Public member functions ]]
--------------------------------------------------------------------------

function self:Init(config, nocheck)
    if not ThePlayer then
        return false
    end
    
    _cfg = config
    
    if nocheck then
        return
    end
    
    
    _weapon = _helper.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)

    if not _weapon then
        tools.talk("没有武器")
        return false
    end
    
    _nmt = _helper:Item(NMT)
    
    if not _nmt then
        tools.talk("没有铥矿徽章")
        return false
    end
    
    local crops = _helper:Find(nil, _cfg.general.range, nil, nil, nil, nil, function(e) return _cfg.pick[e.prefab] end)
 
    if #crops == 0 then
        tools.talk("没有作物")
        return false
    end
    
    if _is_wicker and not _helper.builder:KnowsRecipe(BOOK_ITEM) then
        tools.talk("需解锁 " .. tools.get_name(BOOK_ITEM))
        return false
    end
    
    tools.send("作物: ".. #crops)
	--
	--_error = nil
    _report_time = os.time()
    _death = 0
    _death_cost = 0
    _is_death = false
    _coin = _helper.gftrade:GetCoin()
    _reservecoin = _helper.gftrade:GetReserveCoin()
    _credit = _helper.gftrade:GetIntegral() or 0
    
   -- _keep_item = {}
    --_pack_item = {}
   --_cd_item = {}
    --_equips = {}
    
    _start_pos = self.inst:GetPosition()
    self.pos = _start_pos
    _start_time = os.time()
    --_last_pos = _start_pos
    --_current_pos = _start_pos
    --_next_pos = _start_pos
    --_round = -1
    --_interval_time = os.time()
    --_forge_record = {}
    _revive_record = {}
	--[[
    _death_cost = 0
	_credit = _helper.gftrade:GetIntegral() or 0
    _start_pos = self.inst:GetPosition()
    self.pos = _start_pos
    _coin = _helper.gftrade:GetCoin()
	_reservecoin = _helper.gftrade:GetReserveCoin()
    _start_time = os.time()
    _report_time = os.time()]]
    
    return true
end

function self:Main()
    self.run = true
    while self.run do
        RefreshItem()
        if TheNet:GetServerName() == "" then
            return("已断开连接")
        elseif os.time() - _report_time > 60 then
            --tools.send("已运行: " .. str_play_time(os.time() - _start_time) .. "怪物币" .. (_helper.gftrade:GetCoin() - _coin).."储蓄币".._helper.gftrade:GetReserveCoin() - _reservecoin)
			tools.send(string.format("已运行: %s 怪物币: %d 储备金: %d 积分: %d 死亡: %d 复活: %d", str_play_time(os.time() - _start_time), _helper.gftrade:GetCoin() - _coin, _helper.gftrade:GetReserveCoin() - _reservecoin, _helper.gftrade:GetIntegral() - _credit, _death, _death_cost))            
            _report_time = os.time()
        elseif self.inst:HasTag("corpse") then
		    if not _is_death then
                tools.talk("已死亡", true)
                _is_death = true
                _death = _death + 1
            end
            TheNet:SendSlashCmdToServer("giveup", true)
        elseif self.inst:HasTag("playerghost") then
            local cost = _helper.gflevel:GetLevel() * 20
            if not _helper.gftrade:Afford(cost) then
                return("复活金币不足 " .. cost)
            else
                TheNet:SendSlashCmdToServer("revivehere", true)
            end
		elseif _is_death then
            _is_death = false
            _death_cost = _death_cost + _helper.gflevel:GetLevel() * 20
            table.insert(_revive_record, os.time())
        elseif not _weapon:IsValid() then
            return("武器丢失")
        elseif not _weapon.replica.inventoryitem:IsGrandOwner(self.inst) then
            _helper:Do(nil, _weapon)
        elseif _helper.inventory:GetActiveItem() then
            if _es > 0 then
                _helper.inventory:ReturnActiveItem()
            else
                _helper.inventory:DropItemFromInvTile(_helper.inventory:GetActiveItem())
            end
        elseif not _weapon.replica.equippable:IsEquipped() then
            _helper.inventory:UseItemFromInvTile(_weapon)
        elseif ShouldAttack() then--攻击
            _helper:Attack(_mob)
        elseif _helper.hunger:GetCurrent() < 20 and (_items[CAVE_FUEL] or _helper.gftrade:Afford(FOOD_PRICE) and _es > 0) then--吃食物
            local food = _helper:Item(FOOD)
            if food then
                _helper.inventory:UseItemFromInvTile(food)
            else
                _helper:Buy(FOOD)
            end
        elseif ShouldFuel() then--护符
            local fuel = _helper:Item(CAVE_FUEL)
            if fuel then
                _helper.inventory:ControllerUseItemOnItemFromInvTile(_equip, fuel)
            else
                _helper:Buy(CAVE_FUEL)
            end
        elseif ShouldPick() and _es > 0 then--采集作物
            _helper:Do(nil, _crop)
        elseif ShouldSell() then
            DoSell()
        elseif ShouldIce() then--灭火器
            local start = os.time()
            
            while self.run and ShouldIce() and not ShouldAttack() and os.time() - start < 15 do
                local active = _helper.inventory:GetActiveItem()
                
                if active and active.prefab == ICE_FUEL then
                    _helper:Do(nil, _ice)
                elseif not _helper:Take(ICE_FUEL) then
                    _helper:Buy(ICE_FUEL)
                end
                Sleep(0.1)
            end
            
            if _helper.inventory:GetActiveItem() then
                _helper.inventory:ReturnActiveItem()
                Sleep(0.1)
            end
            
            if os.time() - start > 15 then
                _helper:GoToPoint(_start_pos)
                Sleep(1)
            end
        elseif ShouldBarren() then--施肥
            local start = os.time()
            
            while self.run and ShouldBarren() and not ShouldAttack() and os.time() - start < 15 do
                local active = _helper.inventory:GetActiveItem()
                
                if active and active.prefab == BARREN_ITEM then
                    _helper:Do(nil, _crop)
                elseif not _helper:Take(BARREN_ITEM) then
                    _helper:Buy(BARREN_ITEM, true)
                end
                Sleep(0.1)
            end
            
            if _helper.inventory:GetActiveItem() then
                _helper.inventory:ReturnActiveItem()
                Sleep(0.1)
            end
            
            if os.time() - start > 15 then
                _helper:GoToPoint(_start_pos)
                Sleep(1)
            end
		elseif _items[BOOK_ITEM] and not ShouldPick() then
            _helper.inventory:UseItemFromInvTile(_items[BOOK_ITEM].ent[1])
        elseif self.inst:GetDistanceSqToPoint(_start_pos:Get()) > 4 then
            _helper:GoToPoint(_start_pos)
        elseif _items.cutreeds and _items.cutreeds.count > 3 and _es > 0 then
            while self.run and _helper:Make(BOOK_RAW) and not ShouldAttack() do
                Sleep(0.1)
            end
        elseif _cfg.pick.reeds and ShouldPack() and _items[WRAP_ITEM] then
            _helper.inventory:UseItemFromInvTile(_items[WRAP_ITEM].ent[1])
            Sleep(0.5)
            
            local bundle = _helper:Find(nil, 4, { "bundle", "_container" }, nil, nil, nil, function(e) return  e.replica.container:IsOpenedBy(self.inst) end)[1]
            
            if bundle then
                local start = os.time()
                while bundle:IsValid() and bundle.replica.container and not bundle.replica.container:IsFull() and not ShouldAttack() and  os.time() - start < 3 do
                    for _, v in ipairs(_pack) do
                        v.container:MoveItemFromAllOfSlot(v.slot, bundle)
                        Sleep(0.5)
                    end
                end
                
                if bundle:IsValid() and bundle.replica.container and bundle.replica.container:IsFull() then
                    SendRPCToServer(RPC.DoWidgetButtonAction, ACTIONS.WRAPBUNDLE.code, bundle, ACTIONS.WRAPBUNDLE.mod_name)
                    Sleep(0.5)
                end
            end
        elseif TheWorld.state.iswinter or not _is_wicker then
            Sleep(1)
        elseif _helper:CanMake(BOOK_ITEM) then
            _helper:MakeRecipe(BOOK_ITEM)
        elseif ShouldUnpack() then
            _helper.inventory:UseItemFromInvTile(_unpack)
        else
            tools.talk("没有莎草纸")
            Sleep(2)
        end
		Sleep(0.05)
    end
    
    self:Clean()
end

function self:Clean()
    DoSell(true)
end

--------------------------------------------------------------------------
--[[ End ]]
--------------------------------------------------------------------------

end)