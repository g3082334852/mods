if #data.weaponskill == 1 then--特性只有一个
    local r = 特性名称
    local m = 剩余锻造次数
    if r ~= nil and r ~= "re" then--特性只有一个且不是重锻
        r = r:gsub("_s","")
        return r, data.weaponskill[1].name
    elseif r == "m_s" and m < 5 then
        return "rs", data.weaponskill[1].name
    end
elseif  #data.weaponskill == 2 then--特性有两个个
    local n1 = data.weaponskill[1].name --第一个特性的name
    local n2 = data.weaponskill[2].name --第二个特性的name
    local m = item.replica.forgeable:GetDur()
    local r1 = group.skills[n1] --第一个特性的锻造方式
    local r2 = group.skills[n2] --第二个特性的锻造方式
    
    if r1 and (r1 == "rf" or r1 == "rs") then --如果 r1 是 "保留" 或 "分解"，则返回 r1 和 n1；
        return r1, n1
    elseif r2 and (r2 == "rf" or r2 == "rs") then --如果 r2 是 "保留" 或 "分解"，则返回 r2 和 n2；
        return r2, n2
    elseif r1 and (r1 == "m" and m < 5) then
        return "rs", n1
    elseif r2 and (r2 == "m" and m < 5) then
        return r2, n2
    elseif r1 and r2 then 
        if r1 == "re" or r2 == "re" then --其中有一个特性是重锻，则返回重锻
            return "re"
        elseif r1 == "rs_s" and r2 == "rs_s" then--两个特性都是分解单特
            return "rs", n1..n2
        else
            return "rf", n1..n2
        end
    end
end