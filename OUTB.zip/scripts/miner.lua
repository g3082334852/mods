--------------------------------------------------------------------------
--[[ Miner class definition ]]
--------------------------------------------------------------------------
return Class(function(self, inst)

--------------------------------------------------------------------------
--[[ Dependencies ]]
--------------------------------------------------------------------------

local Helper = require "helper"
local Parser = require "parser"
local tools = require "tools"
local os = require "os"

--------------------------------------------------------------------------
--[[ Constants ]]
--------------------------------------------------------------------------

local MAX_ROCKS_PER_POND = 13
local DELAY_THRESHOLD = 10
local STOP_THRESHOLD = 4
local MINE_ITEM = "staff_tornado"
local EXPLODE_ITEM = "gunpowder"
local EXPLODE_RAW = "rottenegg"
local EXPLODE_PACK = "gift"
local CAVE_FUEL = "lightbulb"
local FOOD = "meatballs"
local FOOD_PRICE = 120
local NMT = "nightmare_timepiece"
local WRAP_ITEM = "giftwrap"

local CONFIG_LIST = {
    general = {
        "range"
    },
    pick = {
        "fossil_piece",
        "ore_gray",
        "ore_green",
        "ore_blue",
        "ore_purple",
        "ore_orange",
        "flame_soul"
    }
}

--------------------------------------------------------------------------
--[[ Member variables ]]
--------------------------------------------------------------------------

--Public
self.inst = inst
self.name = "自动炸矿"
self.prefix = "miner"
self.config = CONFIG_LIST
self.run = false

--Private
local _helper
local _parser
local _phase
local _data
local _cfg
local _ontalkfn
local _start_pos
local _pond
local _mob
local _rock
local _equip
local _items, _es
local _weapon
local _loot
local _pack
local _unpack
local _nmt
local _waste

--------------------------------------------------------------------------
--[[ Private event handlers ]]
--------------------------------------------------------------------------

local function OnPhaseChanged(phase)
    if phase == _phase then
        return
    end
    
    if phase == "day" then
        _data = {}
    end
    
    _phase = phase
end

local function OnTalk(inst, data)
    if self.run and data and data.message and _pond and _pond:IsValid() then
        if string.find(data.message, "空荡荡") then
            _data[_pond] = true
            _waste = _waste + 1
        end
        if string.find(data.message, "周围") then
            _waste = _waste + 1
        end
    end
    if _ontalkfn then
        _ontalkfn(inst, data)
    end
end

--------------------------------------------------------------------------
--[[ Initialization ]]
--------------------------------------------------------------------------

_helper = Helper(inst)
_parser = Parser(inst)
_data = {}
_ontalkfn = inst.components.talker.ontalkfn
inst.components.talker.ontalkfn = OnTalk
self.inst:ListenForEvent("phasechanged", function(inst, data) OnPhaseChanged(data) end, TheWorld)

--------------------------------------------------------------------------
--[[ Private member functions ]]
--------------------------------------------------------------------------

local function RefreshItem()
    _items, _es = _helper:Items()
    return true
end

local function FindPond(fn)
    return _helper:Find(nil, _cfg.general.range, nil, nil, nil, "lava_pond", fn)
end

local function ShouldFuel()
    if not TheWorld.state.isnight then return end
    _equip = _helper:Equip("CAVE_fueled", 20)
    
    if _equip then
        return true
    end
end

local function ShouldAttack()
    local mobs = _helper:Find(nil, 16, {"_combat", "_health"}, {"FX", "NOCLICK", "DECOR", "INLIMBO", "wall"}, nil, nil, function(e)
        if e and e:IsValid() and
            not e.replica.health:IsDead() and
            _helper.combat:CanTarget(e) and
            e.replica.combat:GetTarget() == self.inst then
            return true
        end
    end)
    if mobs and #mobs > 0 then
        _mob = mobs[1]
        return true
    end
end

local function ShouldMine()
    if not (_items[MINE_ITEM] or _helper:CanMake(MINE_ITEM)) or TheWorld.state.iswinter then
        return
    end
    
    local rocks = _helper:Find(nil, 8, nil, nil, nil, nil, function(e) return e:IsValid() and string.find(e.prefab, "pond_rock") and (not e.last or os.time() - e.last > 2) end)
    
    if rocks and #rocks > 0 then
        _rock = rocks[1]
        return true
    end
    
    return false
end

local function ShouldExplode(pond)
    if not TheWorld.state.iswinter or not _items[EXPLODE_ITEM] or not (_items[MINE_ITEM] or _helper:CanMake(MINE_ITEM)) then
        return
    end
    
    if pond then
        return not _data[pond]
    end
    
    local ponds = FindPond(function(e) return not _data[e] and e:GetDistanceSqToPoint(_start_pos:Get()) < _cfg.general.range * _cfg.general.range end)
    
    if ponds and #ponds > 0 then
        _pond = ponds[1]
        return true
    end
end

local function ShouldPick()
    local loots = _helper:Find(nil, _cfg.general.range, {"_inventoryitem"}, {"FX", "NOCLICK", "DECOR", "INLIMBO"}, nil, nil, function(e) return _cfg.pick[e.prefab] and e.replica.inventoryitem:CanBePickedUp() end)
    
    if loots and #loots > 0 then
        _loot = loots[1]
        return true
    end
end

local function ShouldSell()
    for k, v in pairs(_cfg.pick) do
        if v == 1 and _items[k] then
            return true
        end
    end
end

local function ShouldPack()
    if not _items[WRAP_ITEM] then
        return
    end
    
    _pack = {}
	local _pack_keep = {}
    local _pack_drop = {}
    _helper:IterateInventory(function(e,i,c)
        if e and _cfg.pick[e.prefab] and _cfg.pick[e.prefab] == 2 and tools.is_full(e) then
            table.insert(_pack, {item = e, slot = i, container = c})
		    if #_pack_keep > 9 then
                _pack = _pack_keep
                return true
            elseif #_pack_drop > 9 then
                _pack = _pack_drop
                return true
            end
        end
    end)
    if _helper:IsFull() then
                if #_pack_keep >= 0x2 then
                    _pack = _pack_keep
                    return true
                elseif #_pack_drop >= 0x2 then
                    _pack = _pack_drop
                    return true
                end
                return #_pack >= 0x2
            end
            return #_pack >= 0x9
    end

local function ShouldUnpack()
    if _items[EXPLODE_ITEM] then
        return
    end
    
    _unpack = nil
    
    _helper:IterateInventory(function(e)
        if e and e.prefab == EXPLODE_PACK and not e.skip then
            local data = _parser:GetShowMeData(e, 3600, 3)
            if data and data.items then
                for i, v in ipairs(data.items) do
                    if v.prefab == EXPLODE_ITEM or v.prefab == EXPLODE_RAW then
                        _unpack = e
                        return true
                    end
                end
            end
        end
    end)
    
    return _unpack
end

local function DoSell(force)
    while self.run or force do
        _helper:IterateInventory(function(e)
            if e and e.prefab and _cfg.pick[e.prefab] and _cfg.pick[e.prefab] == 1 then
                _helper.inventory:ControllerUseItemOnItemFromInvTile(_nmt, e)
                Sleep(0.1)
            end
        end)
        
        RefreshItem()
        
        if not ShouldSell() or ShouldAttack() then
            break
        end
    end
end

--------------------------------------------------------------------------
--[[ Public member functions ]]
--------------------------------------------------------------------------

function self:Init(config, nocheck)
    if not ThePlayer then
        return false
    end
    
    _cfg = config
    
    if nocheck then
        return
    end
    
    _weapon = _helper.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)

    if not _weapon then
        tools.talk("没有武器")
        return false
    end
    
    _nmt = _helper:Item(NMT)
    
    if not _nmt then
        tools.talk("没有铥矿奖章")
        return false
    end
    
    if not _helper.builder:KnowsRecipe(EXPLODE_ITEM) then
        tools.talk("需解锁 " .. tools.get_name(EXPLODE_ITEM))
        return false
    end
    
    local ponds = FindPond()
    
    if #ponds == 0 then
        tools.talk("没有岩浆池")
        return false
    end
    
    tools.send("岩浆池: " .. #ponds)
    _waste = 0
    _start_pos = self.inst:GetPosition()
    self.pos = _start_pos
    
    return true
end

function self:Main()
    self.run = true
    while self.run do
        RefreshItem()
        if TheNet:GetServerName() == "" then
            return("已断开连接")
        elseif self.inst:HasTag("corpse") then
            TheNet:SendSlashCmdToServer("giveup", true)
        elseif self.inst:HasTag("playerghost") then
            local cost = _helper.gflevel:GetLevel() * 20
            if not _helper.gftrade:Afford(cost) then
                return("复活金币不足 " .. cost)
            else
                TheNet:SendSlashCmdToServer("revivehere", true)
            end
        elseif not _weapon:IsValid() then
            return("武器丢失")
        elseif not _weapon.replica.inventoryitem:IsGrandOwner(self.inst) then
            _helper:Do(nil, _weapon)
        elseif _helper.inventory:GetActiveItem() then
            _helper.inventory:ReturnActiveItem()
        elseif not _weapon.replica.equippable:IsEquipped() then
            _helper.inventory:UseItemFromInvTile(_weapon)
        elseif ShouldAttack() then
            _helper:Attack(_mob)
        elseif _helper.hunger:GetCurrent() < 20 and (_items[FOOD] or _helper.gftrade:Afford(FOOD_PRICE) and _es > 0) then
            local food = _helper:Item(FOOD)
            if food then
                _helper.inventory:UseItemFromInvTile(food)
            else
                _helper:Buy(FOOD)
            end
        elseif ShouldFuel() then
            local fuel = _helper:Item(CAVE_FUEL)
            if fuel then
                _helper.inventory:ControllerUseItemOnItemFromInvTile(_equip, fuel)
            else
                _helper:Buy(CAVE_FUEL)
            end
        elseif ShouldPick() and _es > 1 then
            _helper:Do(nil, _loot)
        elseif ShouldSell() then
            DoSell()
        elseif ShouldPack() then
                _helper["inventory"]:UseItemFromInvTile(_items[WRAP_ITEM]["ent"][0x1])
                    Sleep(0.5)
                local bundle =_helper:Find(nil,0x4,{"bundle", "_container"},nil,nil,nil,function(e)
                        return e["replica"]["container"]:IsOpenedBy(self["inst"])
                    end)[0x1]
                if bundle then
                    local start = os["time"]()
                    while bundle:IsValid() and bundle["replica"]["container"] and 
					not bundle.replica.container:IsFull() and
                    not ShouldAttack() and os.time() - start < 0x3 do
                            for _, v in ipairs(_pack) do
                                v.container:MoveItemFromAllOfSlot(v.slot,bundle)
                                Sleep(0.1)
                            end
                        end
                        if bundle:IsValid() and bundle.replica.container and
                                #bundle.replica.container:GetItems() >= 0x2 then
                            SendRPCToServer(
                                RPC.DoWidgetButtonAction,ACTIONS.WRAPBUNDLE.code,bundle,ACTIONS.WRAPBUNDLE.mod_name)
                            Sleep(0x1)
                        end
                    end
        elseif ShouldExplode() then
            local mine = false
            local _pond_pos = _pond:GetPosition()
            while self.run and RefreshItem() and not ShouldAttack() do
                local rocks = _helper:Find(nil, 12, nil, nil, nil, nil, function(e) return e:IsValid() and string.find(e.prefab, "pond_rock") and e:GetDistanceSqToPoint(_pond:GetPosition():Get()) < 64 end)
                
                if #rocks <= STOP_THRESHOLD then
                    mine = false
                elseif #rocks >= MAX_ROCKS_PER_POND then
                    if not mine then
                    
                    end
                    mine = true
                end
                
                if mine then
                    if _helper.inventory:GetActiveItem() then
                        _helper.inventory:ReturnActiveItem()
                    end
                    
                    if self.inst:GetDistanceSqToPoint(_pond_pos) < 10 then
                        local pos = self.inst:GetPosition()
                        local mine_pos = Point(2 * pos.x - _pond_pos.x, 0, 2 * pos.z - _pond_pos.z)
                        
                        while self.run do
                            _helper:GoToPoint(mine_pos)
                            if self.inst:GetDistanceSqToPoint(mine_pos:Get()) < 2 then
                                break
                            end
                            Sleep(0.2)
                        end
                    else
                        local hand = _helper.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
                        
                        if hand and hand.prefab == MINE_ITEM then


                            _helper:Do(nil, rocks[#rocks], ACTIONS.CASTSPELL)
                            Sleep(0.4)
                        else
                            local tor = _helper:Item(MINE_ITEM)
                            
                            if tor then
                                _helper.inventory:UseItemFromInvTile(tor)
                            elseif _helper:CanMake(MINE_ITEM) then
                                _helper:MakeRecipe(MINE_ITEM)
                            else
                                break
                            end
                        end
                    end
                elseif not _data[_pond] then
                    local active = _helper.inventory:GetActiveItem()
                    
                    if active and active.prefab == EXPLODE_ITEM then
                        _helper:Do(nil, _pond)
                        
                        if #rocks >= DELAY_THRESHOLD then
                            Sleep(0.3)
                        end
                    elseif _helper:Take(EXPLODE_ITEM) then
                        _helper:Do(nil, _pond)
                    else
                        break
                    end
                else
                    break
                end
                
                Sleep(0.2)
            end
        elseif _items[EXPLODE_RAW] then
            while self.run and RefreshItem() and _items[EXPLODE_RAW] and not ShouldAttack() do
                if not _helper:Has("charcoal") then
                    _helper:Buy("charcoal", true)
                elseif not _helper:Has("nitre") then
                    _helper:Buy("nitre", true)
                else
                    _helper:Make(EXPLODE_ITEM)
                end
                Sleep(0.1)
            end
        elseif ShouldUnpack() then
            _helper.inventory:UseItemFromInvTile(_unpack)
        elseif not TheWorld.state.iswinter and ShouldMine() then
            if _rock:GetDistanceSqToPoint(self.inst:GetPosition():Get()) > 50 then
                _helper:GoToPoint(_rock:GetPosition())
            else
                while self.run and not ShouldAttack() and _rock:IsValid() do
                    local hand = _helper.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
                    
                    if hand and hand.prefab == MINE_ITEM then
                        _helper:Do(nil, _rock, ACTIONS.CASTSPELL)
                        _rock.last = os.time()
                        Sleep(1)
                    else
                        local tor = _helper:Item(MINE_ITEM)
                        
                        if tor then
                            _helper.inventory:UseItemFromInvTile(tor)
                        else
                            _helper:MakeRecipe(MINE_ITEM)
                        end
                    end
                    
                    Sleep(0.2)
                end

            end
        elseif self.inst:GetDistanceSqToPoint(_start_pos:Get()) > 16 then
            _helper:GoToPoint(_start_pos)
        end
        Sleep(0.2)
    end
    self:Clean()
end

function self:Clean()
    tools.send("浪费火药: " .. _waste)
end

--------------------------------------------------------------------------
--[[ End ]]
--------------------------------------------------------------------------

end)