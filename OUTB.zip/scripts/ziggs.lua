--------------------------------------------------------------------------
--[[ Miner class definition ]]
--------------------------------------------------------------------------
return Class(function(self, inst)

--------------------------------------------------------------------------
--[[ Dependencies ]]
--------------------------------------------------------------------------

local Helper = require "helper"
local Parser = require "parser"
local tools = require "tools"
local os = require "os"

--------------------------------------------------------------------------
--[[ Constants ]]
--------------------------------------------------------------------------

local STOP_THRESHOLD = 4
local PGP = "gunpowder"
local PRE = "rottenegg"
local PGI = "gift"

local EXPLODE_ITEM = "gunpowder"
local EXPLODE_RAW = "rottenegg"
local EGG = "egg"
local EXPLODE_PACK = "gift"
local CAVE_FUEL = "lightbulb"
local FOOD = "meatballs"
local FOOD_PRICE = 120
local WRAP_ITEM = "giftwrap"

local CONFIG_LIST = {}

--------------------------------------------------------------------------
--[[ Member variables ]]
--------------------------------------------------------------------------

--Public
self.inst = inst
self.name = "搓火药"
self.prefix = "ziggs"
self.config = CONFIG_LIST
self.run = false

--Private
local _helper
local _parser
local _cfg
local _start_pos
local _mob
local _rock
local _equip
local _items, _es
local _weapon
local _loot
local _pack
local _unpack
local _chest

--------------------------------------------------------------------------
--[[ Private event handlers ]]
--------------------------------------------------------------------------

--------------------------------------------------------------------------
--[[ Initialization ]]
--------------------------------------------------------------------------

_helper = Helper(inst)
_parser = Parser(inst)

--------------------------------------------------------------------------
--[[ Private member functions ]]
--------------------------------------------------------------------------

local function RefreshItem()
    _items, _es = _helper:Items()
    return true
end

local function Afford(prefab)
    return _items[prefab] or _helper:Afford(prefab) and _es > 0
end

local function IsNeed(item)
    if type(item) == "table" then
        if _empty > 0 and IsForgeable(item) and not _helper:Has(nil, nil, function(e) return IsForgeable(e) end, math.min(_empty, 8)) and _es > 1 then
            return true
        elseif item.prefab == GIFT then
            local data = _parser:GetShowMeData(item, 3600, 3)
            if data and data.items then
                for i, v in ipairs(data.items) do
                    if IsNeed(v.prefab) then
                        item.unpack = true
                        return true
                    end
                end
            end
        else
            return IsNeed(item.prefab)
        end
    elseif type(item) == "string" and _need[item] and _es > 1 and not Has(item, MAX_RAW) then
        return true
    end
end

local function ShouldFuel()
    if not TheWorld.state.isnight then return end
    _equip = _helper:Equip("CAVE_fueled", 20)
    
    if _equip then
        return true
    end
end

local function ShouldAttack()
    local mobs = _helper:Find(nil, 16, {"_combat", "_health"}, {"FX", "NOCLICK", "DECOR", "INLIMBO", "wall"}, nil, nil, function(e)
        if e and e:IsValid() and
            not e.replica.health:IsDead() and
            _helper.combat:CanTarget(e) and
            e.replica.combat:GetTarget() == self.inst then
            return true
        end
    end)
    if mobs and #mobs > 0 then
        _mob = mobs[1]
        return true
    end
end

local function ShouldPick()
    local loots = _helper:Find(nil, 16, {"_inventoryitem"}, {"FX", "NOCLICK", "DECOR", "INLIMBO"}, nil, nil, function(e) return e and e.prefab and e.prefab == EGG and e.replica.inventoryitem:CanBePickedUp() end)
    
    if loots and #loots > 0 then
        _loot = loots[1]
        return true
    end
end

local function ShouldPack()
    if not _items[WRAP_ITEM] then
        return
    end
    
    _pack = {}
	local _pack_keep = {}
    local _pack_drop = {}
    _helper:IterateInventory(function(e,i,c)
        if e and e.prefab == EXPLODE_ITEM and tools.is_full(e) then
            table.insert(_pack, {item = e, slot = i, container = c})
		    if #_pack_keep > 9 then
                _pack = _pack_keep
                return true
            elseif #_pack_drop > 9 then
                _pack = _pack_drop
                return true
            end
        end
    end)
    if _helper:IsFull() then
                if #_pack_keep >= 0x2 then
                    _pack = _pack_keep
                    return true
                elseif #_pack_drop >= 0x2 then
                    _pack = _pack_drop
                    return true
                end
                return #_pack >= 0x2
            end
            return #_pack >= 0x9
    end

local function ShouldUnpack()
    _unpack = nil
    
    _helper:IterateInventory(function(e)
        if e and e.prefab == EXPLODE_PACK then
            local data = _parser:GetShowMeData(e, 3600, 3)
            if data and data.items then
                for i, v in ipairs(data.items) do
                    if v.prefab == EXPLODE_RAW then
                        _unpack = e
                        return true
                    end
                end
            end
        end
    end)
    
    return _unpack
end

--------------------------------------------------------------------------
--[[ Public member functions ]]
--------------------------------------------------------------------------

function self:Init(config, nocheck)
    if not ThePlayer then
        return false
    end
    
    _cfg = config
    
    if nocheck then
        return
    end
    
    _weapon = _helper.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)

    if not _weapon then
        tools.talk("没有武器")
        return false
    end
    
    if not _helper.builder:KnowsRecipe(EXPLODE_ITEM) then
        tools.talk("需解锁 " .. tools.get_name(EXPLODE_ITEM))
        return false
    end
    
    _start_pos = self.inst:GetPosition()
    self.pos = _start_pos
    
    return true
end

function self:Main()
    self.run = true
    while self.run do
        RefreshItem()
        if TheNet:GetServerName() == "" then
            return("已断开连接")
        elseif self.inst:HasTag("corpse") then
            TheNet:SendSlashCmdToServer("giveup", true)
        elseif self.inst:HasTag("playerghost") then
            local cost = _helper.gflevel:GetLevel() * 20
            if not _helper.gftrade:Afford(cost) then
                return("复活金币不足 " .. cost)
            else
                TheNet:SendSlashCmdToServer("revivehere", true)
            end
        elseif not _weapon:IsValid() then
            return("武器丢失")
        elseif not _weapon.replica.inventoryitem:IsGrandOwner(self.inst) then
            _helper:Do(nil, _weapon)
        elseif _helper.inventory:GetActiveItem() then
            _helper.inventory:ReturnActiveItem()
        elseif not _weapon.replica.equippable:IsEquipped() then
            _helper.inventory:UseItemFromInvTile(_weapon)
        elseif ShouldAttack() then
            _helper:Attack(_mob)
        elseif _helper.hunger:GetCurrent() < 20 and Afford(FOOD) then
            local food = _helper:Item(FOOD)
            if food then
                _helper.inventory:UseItemFromInvTile(food)
            else
                _helper:Buy(FOOD)
                Sleep(0.3)
            end
        elseif ShouldFuel() then
            local fuel = _helper:Item(CAVE_FUEL)
            if fuel then
                _helper.inventory:ControllerUseItemOnItemFromInvTile(_equip, fuel)
            else
                _helper:Buy(CAVE_FUEL)
                Sleep(0.3)
            end
        elseif ShouldPick() and _es > 1 then
            _helper:Do(nil, _loot)
		elseif ShouldPack() then
                _helper.inventory:UseItemFromInvTile(_items[WRAP_ITEM].ent[1])
                Sleep(0.5)
				
                local bundle =_helper:Find(nil,0x4,{"bundle", "_container"},nil,nil,nil,function(e) return e.replica.container:IsOpenedBy(self.inst) end)[0x1]
                if bundle then
                    local start = os.time()
                    while bundle:IsValid() and bundle.replica.container and not bundle.replica.container:IsFull() and not ShouldAttack() and os.time() - start < 0x3 do
                            for _, v in ipairs(_pack) do
                                v.container:MoveItemFromAllOfSlot(v.slot,bundle)
                                Sleep(0.1)
                            end
                        end
                        if bundle:IsValid() and bundle.replica.container and
                                #bundle.replica.container:GetItems() >= 0x2 then
                            SendRPCToServer(
                                RPC.DoWidgetButtonAction,ACTIONS.WRAPBUNDLE.code,bundle,ACTIONS.WRAPBUNDLE.mod_name)
                            Sleep(0x1)
                        end
                    end
        elseif _items[EXPLODE_RAW] then
            while self.run and RefreshItem() and _items[EXPLODE_RAW] and not ShouldAttack() do
                if not _helper:Has("charcoal") then
                    _helper:Buy("charcoal", true)
                elseif not _helper:Has("nitre") then
                    _helper:Buy("nitre", true)
                else
                    _helper:Make(EXPLODE_ITEM)
                end
                Sleep(0.1)
            end
        elseif ShouldUnpack() then
            _helper.inventory:UseItemFromInvTile(_unpack)
        elseif self.inst:GetDistanceSqToPoint(_start_pos:Get()) > 16 then
            _helper:GoToPoint(_start_pos)
        end
        Sleep(0.2)
    end
    self:Clean()
end

function self:Clean()
end

--------------------------------------------------------------------------
--[[ End ]]
--------------------------------------------------------------------------

end)