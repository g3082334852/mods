--------------------------------------------------------------------------
--[[ Global variables ]]
--------------------------------------------------------------------------

local PRICE_LIST = {}

--------------------------------------------------------------------------
--[[ Helper class definition ]]
--------------------------------------------------------------------------

return Class(function(self, inst)

--------------------------------------------------------------------------
--[[ Dependencies ]]
--------------------------------------------------------------------------

require "json"
local tools = require "tools"

--------------------------------------------------------------------------
--[[ Member variables ]]
--------------------------------------------------------------------------

self.inst = inst
self.inst:EnableMovementPrediction(true)
self.locomotor = self.inst.components.locomotor
self.inventory = self.inst.replica.inventory
self.playercontroller = self.inst.components.playercontroller
self.playeractionpicker = self.inst.components.playeractionpicker
self.builder = self.inst.replica.builder
self.combat = self.inst.replica.combat
self.hunger = self.inst.replica.hunger
self.sanity = self.inst.replica.sanity
self.health = self.inst.replica.health
self.gftrade = self.inst.replica.gftrade
self.gflevel = self.inst.replica.gflevel

--------------------------------------------------------------------------
--[[ Initialization ]]
--------------------------------------------------------------------------

if EBSHOP then
    for _, v in pairs(EBSHOP.PriceList) do
        for _, p in ipairs(v) do
            PRICE_LIST[p.prefab] = p
            print(p.prefab)
        end
    end
end

--------------------------------------------------------------------------
--[[ Public member functions ]]
--------------------------------------------------------------------------

function self:Attack(target)
    local canhit = self.combat:CanHitTarget(target)
    if target and target:IsValid() and (not self.inst.sg or not self.inst.sg:HasStateTag("abouttoattack")) and not canhit then
        self:GoToTarget(target)
    end

    target = self.playercontroller:GetAttackTarget(true, target, target ~= nil)
    if target then
        if self.locomotor then
            local buffaction = BufferedAction(self.inst, target, ACTIONS.ATTACK)
            buffaction.preview_cb = function()
                self.playercontroller:RemoteAttackButton(target, true)
            end
            self.locomotor:PreviewAction(buffaction, true)
        else
            self.playercontroller:RemoteAttackButton(target, true)
        end
    end
    
    return canhit
end

function self:GoToPoint(pos)
    self.locomotor:GoToPoint(pos, nil, nil)
end

function self:GoToTarget(target)
    self.locomotor:GoToEntity(target, nil, nil)
end

function self:LMBac(pos, target, act)
    pos = pos or target and target:GetPosition() or nil
    if pos then
        if self.locomotor then
            act.preview_cb = function()
                self.playercontroller.remote_controls[CONTROL_PRIMARY] = 0
                SendRPCToServer(RPC.LeftClick, act.action.code, pos.x, pos.z, target, false, nil, false, act.action.mod_name)
            end
        else
            self.playercontroller.remote_controls[CONTROL_PRIMARY] = 0
            SendRPCToServer(RPC.LeftClick, act.action.code, pos.x, pos.z, target, false, nil, false, act.action.mod_name)
        end
        self.playercontroller:DoAction(act)
    end
end

function self:RMBac(pos, target, act)
    pos = pos or target and target:GetPosition() or nil
    if pos then
        local controlmods = self.playercontroller:EncodeControlMods()
        if self.locomotor then
            act.preview_cb = function()
                self.playercontroller.remote_controls[CONTROL_PRIMARY] = 0
                SendRPCToServer(RPC.RightClick, act.action.code, pos.x, pos.z, target, false, nil, controlmods, nil, act.action.mod_name)
            end
        else
            self.playercontroller.remote_controls[CONTROL_PRIMARY] = 0
            SendRPCToServer(RPC.RightClick, act.action.code, pos.x, pos.z, target, false, nil, controlmods, nil, act.action.mod_name)
        end
        self.playercontroller:DoAction(act)
    end
end

function self:Do(pos, target, act, fn, time)
    local dt = time and time > 0 and time or 0.1
    local pt = pos and pos or target and target:GetPosition() or self.inst:GetPosition()
    if pt then
        local LMB, RMB = self.playeractionpicker:DoGetMouseActions(pt, target)
        if LMB and (not act or LMB.action == act) and (not fn or fn(LMB)) then
            self:LMBac(pt, target, LMB)
        elseif RMB and (not act or RMB.action == act) and (not fn or fn(RMB)) then
            self:RMBac(pt, target, RMB)
        end
    end
    Sleep(dt)
end

function self:Make(recname)
    if AllRecipes[recname] and self.builder:CanBuild(recname) then
        self.builder:MakeRecipeFromMenu(AllRecipes[recname])
        Sleep(0.1)
        return true
    end
    return false
end

function self:IterateInventory(fn)
    if not fn then
        return
    end
    
    self:IterateContainer(fn, self.inventory)
    
    local overflow = self.inventory:GetOverflowContainer()
    
    if overflow then
        self:IterateContainer(fn, overflow)
    end
end

function self:IterateContainer(fn, co)
    if not fn or not co then
        return
    end
    
    for i = 1, co:GetNumSlots() do
        if fn(co:GetItemInSlot(i), i, co) then
            return
        end
    end
end

function self:Item(prefab, tag, fn, co)
    local item, slot, container
    
    local function filter(e,i,c)
        if e and e.prefab and (not prefab or e.prefab == prefab) and (not tag or e:HasTag(tag)) and (not fn or fn(e,i,c)) then
            item = e
            slot = i
            container = c
            return true
        end
    end
    
    if co and co:IsValid() and co.replica.container then
        self:IterateContainer(filter, co)
    else
        self:IterateInventory(filter)
    end
    
    return item, slot, container
end

function self:Items(prefab, tag, fn, co)
    local slot = 0
    local items = {}
    
    local function filter(e, i, c)
        if e and e.prefab then
            if (not prefab or e.prefab == prefab) and (not tag or e:HasTag(tag)) and (not fn or fn(e, i, c)) then
                if not items[e.prefab] then
                    items[e.prefab] = {count = 0, ent = {}}
                end
                items[e.prefab].count = items[e.prefab].count + tools.count(e)
                table.insert(items[e.prefab].ent, e)
            end
        else
            slot = slot + 1
        end
    end
    
    if co and co:IsValid() and co.replica.container then
        self:IterateContainer(filter, co)
    else
        self:IterateInventory(filter)
    end
    
    return items, slot
end

function self:Take(prefab, tag, fn)
    if self.inventory:GetActiveItem() then
        self.inventory:ReturnActiveItem()
    end
    
    local item, slot, container = self:Item(prefab, tag, fn)
    
    if item and slot and container then
        container:TakeActiveItemFromAllOfSlot(slot)
        Sleep(0.1)
    end
    
    return item, slot, container
end

function self:MoveIn(prefab, tag, fn, co)
    local item, slot, container = self:Item(prefab, tag, fn)
    
    if item then
        container:MoveItemFromAllOfSlot(slot, co)
    end
    
    return item
end

function self:MoveOut(prefab, tag, fn, co)
    local item, slot, container = self:Item(prefab, tag, fn, co)
    
    if item then
        if not self.inventory:IsFull() then
            co.replica.container:MoveItemFromAllOfSlot(slot, self.inst)
        else
            local overflow = self.inventory:GetOverflowContainer()
            if overflow and not overflow:IsFull() then
                co.replica.container:MoveItemFromAllOfSlot(slot, overflow.inst)
            end
        end
    end
    
    return item, slot, container
end

function self:MoveSlotIn(slot, overflow, co)
    if overflow then
        overflow:MoveItemFromAllOfSlot(slot, co)
    else
        self.inventory:MoveItemFromAllOfSlot(slot, co)
    end
end

function self:MoveSlotOut(slot, co)
    if not self.inventory:IsFull() then
        co.replica.container:MoveItemFromAllOfSlot(slot, self.inst)
    else
        local overflow = self.inventory:GetOverflowContainer()
        if overflow and not overflow:IsFull() then
            co.replica.container:MoveItemFromAllOfSlot(slot, overflow.inst)
        end
    end
end

function self:EmptySlot(num)
    local slot = 0
    self:IterateInventory(function(e) slot = slot + (e and 0 or 1) end)
    if num then
        return slot >= num, slot
    else
        return slot
    end
end

function self:Equip(tag, percent, fn)
    for k, v in pairs(EQUIPSLOTS) do
        local equip = self.inventory:GetEquippedItem(v)
        if equip 
            and (not tag or equip:HasTag(tag))
            and (not percent or equip.replica.inventoryitem.classified.percentused:value() < percent)
            and (not fn or fn(equip))
        then
            return equip, equip.replica.inventoryitem.classified.percentused:value()
        end
    end

    return nil
end

function self:Find(inst, radius, musttags, canttags, mustoneoftags, prefab, fn)
    if not inst then
        inst = self.inst
    end
    
    local x, y, z = inst.Transform:GetWorldPosition()
    local canttags = type(canttags) == "table" and canttags or type(canttags) == "boolean" and {"FX", "NOCLICK", "DECOR", "INLIMBO"} or nil
    local ents = TheSim:FindEntities(x, y, z, radius, musttags, canttags, mustoneoftags)
    if fn ~= nil or prefab ~= nil then
        local filter = {}
        for i, v in ipairs(ents) do
            if v and v.prefab and (not prefab or v.prefab == prefab) and (not fn or fn(v)) then
                table.insert(filter, v)
            end
        end
        return filter
    end
    return ents
end

function self:Has(prefab, tag, fn, num)
    local count = 0
    self:IterateInventory(function(e)
        if e and (not prefab or e.prefab == prefab) and (not tag or e:HasTag(tag)) and (not fn or fn(e)) then
            count = count + tools.count(e)
        end
    end)
    if num then
        return count >= num, count
    else
        return count > 0, count
    end
end

function self:IsFull()
    if not self.inventory:IsFull() then
        return false
    end
    local overflow = self.inventory:GetOverflowContainer()
    
    return not overflow or overflow:IsFull()
end

function self:Buy(prefab, right)
    if not PRICE_LIST[prefab] or (right == true and PRICE_LIST[prefab].rightclick ~= true) then
        return
    end
    
    SendModRPCToServer(MOD_RPC.ebshop.buy, prefab, json.encode({right = right, cate = PRICE_LIST[prefab].type}))
end

function self:Afford(prefab)
    if type(prefab) == "number" then
        return self.gftrade:Afford(prefab)
    elseif type(prefab) == "string" and PRICE_LIST[prefab] then
        return self.gftrade:Afford(EBSHOP.GetRealPrice(PRICE_LIST[prefab], self.inst))
    else
        return false
    end
end

function self:CanMake(recname)
    if AllRecipes[recname] and self.builder:KnowsRecipe(recname) then
        local items, es = self:Items()
        local slot = 0
        local cost = 0
        for _, ingre in ipairs(AllRecipes[recname].ingredients) do
            local has = items[ingre.type] and items[ingre.type].count or 0
            if has == 0 then
                slot = slot + 1
            end
            if has < ingre.amount then
                if PRICE_LIST[ingre.type] then
                    cost = cost + EBSHOP.GetRealPrice(PRICE_LIST[ingre.type], self.inst) * (ingre.amount - has)
                else
                    return false
                end
            end
        end
        
        return self.gftrade:Afford(cost) and es >= slot
    end
    
    return false
end

function self:MakeRecipe(recname, right)
    if AllRecipes[recname] and self.builder:KnowsRecipe(recname) then
        while true do
            local items, es = self:Items()
            local can = true
            
            for _, ingre in ipairs(AllRecipes[recname].ingredients) do
                local need = ingre.amount - (items[ingre.type] and items[ingre.type].count or 0)
                if need > 0 then
                    self:Buy(ingre.type, right or need >= 10)
                    can = false
                    Sleep(0.2)
                end
            end
            
            if can then
                self:Make(recname)
                Sleep(0.2)
                return true
            end
        end
    end
    
    return false
end

end)