local Tools = {}

Tools.wait_for_inited = function()
    while not ThePlayer or not ThePlayer.player_classified or not SendRPCToServer do
        Sleep(0.2)
    end
end

Tools.is_default_screen = function()
    if ThePlayer then
        local screen = TheFrontEnd:GetActiveScreen()
        return ((screen and type(screen.name) == "string") and screen.name or ""):find("HUD") ~= nil and not (ThePlayer.HUD:IsControllerCraftingOpen() or ThePlayer.HUD:IsControllerInventoryOpen())
    end
end

Tools.send = function(msg)
    if msg and #msg > 0 and ThePlayer and ThePlayer.HUD and ThePlayer.HUD.controls and ThePlayer.HUD.controls.networkchatqueue then
        ThePlayer.HUD.controls.networkchatqueue:PushMessage("", msg, {0x0, 0xbf / 0xff, 0x1, 0x1})
        print(msg)
    end
end

Tools.talk = function(msg, bSend)
    if msg and #msg > 0 and ThePlayer and ThePlayer.components.talker then
        ThePlayer.components.talker:Say(msg)
        if bSend then
            Tools.send(msg)
        end
    end
end

Tools.count = function(e)
    return e and e.replica and e.replica.stackable and e.replica.stackable:StackSize() or e and 1 or 0
end

Tools.is_full = function(e)
    return not e.replica.stackable or e.replica.stackable:IsFull()
end

Tools.get_name = function(prefab)
    return STRINGS.NAMES[string.utf8upper(prefab)] or prefab
end

Tools.seconds_str = function(sec)
    local seconds = tonumber(sec)
    if seconds <= 0 then
        return "00分 00秒"
    else
        local hour = math.floor(seconds / 3600)
        local hours = string.format("%02.f", hour)
        local mins = string.format("%02.f", math.floor(seconds / 60 - (hours * 60)))
        local secs = string.format("%02.f", math.floor(seconds - hours * 3600 - mins * 60))
        return hour > 0 and hours .. "小时 " .. mins .. "分 " .. secs .. "秒"  or mins .. "分 " .. secs .. "秒"
    end
end

Tools.get_mod_config = function(args, prefix, modname)
    if type(args) == "table" then
        local result = {}
        
        for k,v in pairs(args) do
            if type(k) == "number" then
                result[v] = Tools.get_mod_config(v, prefix, modname)
            elseif type (k) == "string" then
                result[k] = Tools.get_mod_config(v, prefix .. "_" .. k, modname)
            end
        end
        
        return result
    elseif type(args) == "string" then
        return GetModConfigData(prefix .. "_" .. args, modname)
    end
end

Tools.get_percent = function(e)
    return e and e.replica and e.replica.inventoryitem.classified.percentused:value() or 100
end

return Tools