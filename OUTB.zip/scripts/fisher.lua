--------------------------------------------------------------------------
--[[ Fisher class definition ]]
--------------------------------------------------------------------------

return Class(function(self, inst)

--------------------------------------------------------------------------
--[[ Dependencies ]]
--------------------------------------------------------------------------

local Helper = require "helper"
local tools = require "tools"
local os = require "os"

--------------------------------------------------------------------------
--[[ Constants ]]
--------------------------------------------------------------------------

local FISHING_ITEM = "fishingrod"
local CAVE_FUEL = "lightbulb"
local FOOD = "meatballs"
local FOOD_PRICE = 120
local CONFIG_LIST = {}
local WRAP_ITEM = "giftwrap"

--------------------------------------------------------------------------
--[[ Member variables ]]
--------------------------------------------------------------------------

--Public
self.inst = inst
self.name = "自动钓鱼"
self.prefix = "fisher"
self.config = CONFIG_LIST
self.run = false

--Private
local _cfg
local _helper
local _start_pos
local _items, _es
local _mob
local _equip
local _lake
local _weapon
local _pack

--------------------------------------------------------------------------
--[[ Private event handlers ]]
--------------------------------------------------------------------------

--------------------------------------------------------------------------
--[[ Initialization ]]
--------------------------------------------------------------------------

_helper = Helper(inst)

--------------------------------------------------------------------------
--[[ Private member functions ]]
--------------------------------------------------------------------------

local function RefreshItem()
    _items, _es = _helper:Items()
    return true
end

local function ShouldFuel()
    if not TheWorld.state.isnight then return end
    _equip = _helper:Equip("CAVE_fueled", 20)
    
    if _equip then
        return true
    end
end

local function ShouldAttack()
    local mobs = _helper:Find(nil, 16, {"_combat", "_health"}, {"FX", "NOCLICK", "DECOR", "INLIMBO", "wall"}, nil, nil, function(e)
        if e and e:IsValid() and
            not e.replica.health:IsDead() and
            _helper.combat:CanTarget(e) and
            e.replica.combat:GetTarget() == self.inst then
            return true
        end
    end)
    if mobs and #mobs > 0 then
        _mob = mobs[1]
        return true
    end
end

local function ShouldFish()
    _lake = _helper:Find(nil, 16, { "fishable" })[1]
    
    return _lake
end

local function ShouldMake()
    local hand = _helper.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
    
    if not hand or hand.prefab ~= FISHING_ITEM then
        return true
    end
end

local function ShouldPack()
    if not _items[WRAP_ITEM] then
        return
    end
    
    _pack = {}
    
    _helper:IterateInventory(function(e,i,c)
        if e and e.prefab == "fish" and tools.is_full(e) then
            table.insert(_pack, {slot = i, container = c})
            
            if #_pack > 3 then
                return true
            end
        end
    end)
    
    return #_pack > 3
end

local function ShouldMove()
    local over = _helper.inventory:GetOverflowContainer()
    
    if not over or over:IsFull() then
        return false
    end
    
    local fish = _helper:Item("fish", nil, function(e,i,c) return c.inst == self.inst end)
    
    if fish then
        return true
    end
end

--------------------------------------------------------------------------
--[[ Public member functions ]]
--------------------------------------------------------------------------

function self:Init(config, nocheck)
    if not ThePlayer then
        return false
    end
    
    _cfg = config
    
    if nocheck then
        return
    end
    
    
    _weapon = _helper.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)

    if not _weapon then
        tools.talk("没有武器")
        return false
    end
    
    if not ShouldFish() then
        tools.talk("没有可钓鱼的湖泊")
        return false
    end
    
    if not _helper.builder:KnowsRecipe(FISHING_ITEM) then
        tools.talk("需解锁 " .. tools.get_name(FISHING_ITEM))
        return false
    end
    
    _start_pos = self.inst:GetPosition()
    self.pos = _start_pos
    
    return true
end

function self:Main()
    self.run = true
    while self.run do
        RefreshItem()
        if TheNet:GetServerName() == "" then
            return("已断开连接")
        elseif self.inst:HasTag("corpse") then
            TheNet:SendSlashCmdToServer("giveup", true)
        elseif self.inst:HasTag("playerghost") then
            local cost = _helper.gflevel:GetLevel() * 20
            if not _helper.gftrade:Afford(cost) then
                return("复活金币不足 " .. cost)
            else
                TheNet:SendSlashCmdToServer("revivehere", true)
            end
        elseif not _weapon:IsValid() then
            return("武器丢失")
        elseif not _weapon.replica.inventoryitem:IsGrandOwner(self.inst) then
            _helper:Do(nil, _weapon)
        elseif _helper.inventory:GetActiveItem() then
            if _es > 0 then
                _helper.inventory:ReturnActiveItem()
            else
                _helper.inventory:DropItemFromInvTile(_helper.inventory:GetActiveItem())
            end
        elseif ShouldAttack() then
            if not _weapon.replica.equippable:IsEquipped() then
                _helper.inventory:UseItemFromInvTile(_weapon)
            else
                _helper:Attack(_mob)
            end
        elseif _helper.hunger:GetCurrent() < 20 and (_items[CAVE_FUEL] or _helper.gftrade:Afford(FOOD_PRICE) and _es > 0) then
            local food = _helper:Item(FOOD)
            if food then
                _helper.inventory:UseItemFromInvTile(food)
            else
                _helper:Buy(FOOD)
            end
        elseif ShouldFuel() then
            local fuel = _helper:Item(CAVE_FUEL)
            if fuel then
                _helper.inventory:ControllerUseItemOnItemFromInvTile(_equip, fuel)
            else
                _helper:Buy(CAVE_FUEL)
            end
        elseif ShouldPack() then
            _helper.inventory:UseItemFromInvTile(_items[WRAP_ITEM].ent[1])
            Sleep(0.5)
            
            local bundle = _helper:Find(nil, 4, { "bundle", "_container" }, nil, nil, nil, function(e) return  e.replica.container:IsOpenedBy(self.inst) end)[1]
            
            if bundle then
                local start = os.time()
                while bundle:IsValid() and bundle.replica.container and not bundle.replica.container:IsFull() and not ShouldAttack() and  os.time() - start < 3 do
                    for _, v in ipairs(_pack) do
                        v.container:MoveItemFromAllOfSlot(v.slot, bundle)
                        Sleep(0.1)
                    end
                end
                
                if bundle:IsValid() and bundle.replica.container and bundle.replica.container:IsFull() then
                    SendRPCToServer(RPC.DoWidgetButtonAction, ACTIONS.WRAPBUNDLE.code, bundle, ACTIONS.WRAPBUNDLE.mod_name)
                    Sleep(1)
                end
            end
        elseif ShouldMove() then
            _helper:MoveIn("fish", nil, function(e,i,o) return o ~= _helper.inventory:GetOverflowContainer() end, _helper.inventory:GetOverflowContainer().inst)
        elseif ShouldMake() then
            if _items[FISHING_ITEM] then
                _helper.inventory:UseItemFromInvTile(_items[FISHING_ITEM].ent[1])
            else
                if not _items.twigs or _items.twigs.count < 2 then
                    _helper:Buy("twigs")
                elseif not _items.silk or _items.silk.count < 2 then
                    _helper:Buy("silk")
                else
                    _helper:Make(FISHING_ITEM)
                end
            end
        elseif ShouldFish() then
            _helper:Do(nil, _lake, nil, function(mb) return mb:GetActionString() ~= STRINGS.ACTIONS.REEL.CANCEL end)
        else
            self.run = false
        end
        Sleep(0.2)
    end
end

--------------------------------------------------------------------------
--[[ End ]]
--------------------------------------------------------------------------

end)