GLOBAL.setmetatable(env, { __index = function(t, k) return GLOBAL.rawget(GLOBAL, k) end })
local tools = require "tools"
local PersistentData = require "persistentdata"
local Helper = require "helper"
local tasks = {}
local task_list = {
    "miner",
    "farmer",
    "fisher",
    "ziggs",
    "smith"
}
local task_ctor = {
    miner = require "miner",
    farmer = require "farmer",
    fisher = require "fisher",
    ziggs = require "ziggs",
    smith = require "smith"
}
local is_inited
local main_thread_id = "lazy"
local main_thread
local current = nil
local index = GetModConfigData("default")
local persist = PersistentData(main_thread_id)

local function init_task()
    if is_inited then
        return
    end
    
    for k,v in pairs(task_list) do
        local t = task_ctor[v](ThePlayer)
        t:Init(tools.get_mod_config(t.config, t.prefix, modname), true)
        table.insert(tasks, t)
    end
    current = tasks[index]
    is_inited = true
end

local function on_persist_load()
    local task_info = persist:GetValue("task_info")
    if GetModConfigData("reconnect") and task_info and TheWorld.worldname == task_info.world then
        persist:SetValue("task_info", nil)
        persist:Save()
        index = task_info.index
        ThePlayer:StartThread(function()
            local t = 0
            local helper = Helper(ThePlayer)
            local pos = Point(task_info.pos.x, 0, task_info.pos.z)
            while t < 60 do
                t = t + 1
                if ThePlayer:GetDistanceSqToPoint(pos:Get()) > 10 then
                    helper:GoToPoint(pos)
                else
                    on_hotkeydown()
                    break
                end
                Sleep(1)
            end
        end)
    end
end

local function on_hotkeydown()
    if not ThePlayer or not tools.is_default_screen() then
        return
    end
    
    if main_thread then
        current.run = false
        return
    end
    
    if TheInput.IsKeyDown(TheInput, KEY_SHIFT) then
        index = math.mod(index, #tasks) + 1
        current = tasks[index]
        tools.talk(current.name)
        return
    end
    
    local cfg = tools.get_mod_config(current.config, current.prefix, modname)
    
    if not current:Init(cfg) then
        return
    end
    
    main_thread = ThePlayer:StartThread(function()
        tools.talk(current.name .. "已启动")
        local msg = current:Main()
        if msg then
            tools.talk(msg, true)
        else
            tools.talk(current.name .. "已终止")
        end
        Sleep(0.3)
        main_thread:SetList(nil)
        main_thread = nil
        
        if msg == "已断开连接" and GetModConfigData("reconnect") then
            persist:SetValue("task_info", { pos = current.pos, index = index })
            persist:SetValue("reconnect", true)
            persist:Save(function() DoRestart() end)
        end
    end, main_thread_id)
end

AddClassPostConstruct("screens/redux/mainscreen", function(self)
    persist:Load(function()
        local reconnect = persist:GetValue("reconnect")
        
        if GetModConfigData("reconnect") and reconnect then
            persist:SetValue("reconnect", false)
            persist:Save()
            
            StartThread(function()
                while true do
                    if IsRail() then
                        c_connect("115.231.26.46", 0x2af8)
                    else
                        c_connect("115.231.26.45", 0x2af8)
                    end
                    Sleep(5)
                end
            end)
        end
    end)
end)

AddPlayerPostInit(function(player_inst)
    player_inst:DoTaskInTime(5, function()
        tools.wait_for_inited()
        init_task()
        
        persist:Load(on_persist_load)
    end)
end)

TheInput:AddKeyDownHandler(GetModConfigData("hotkey"), on_hotkeydown)