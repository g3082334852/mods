name = "out懒癌"
author = "out"
version = "2.1"
forumthread = ""
description = [[
2022更新-剩余五次分解
2023.2.23更新-打包改为九格，物品栏剩余两格打包
2023.2.30更新-分类稀有橙和毕业甲、新增日炎
2023.3.19更新-增加自动购买分解符
]]
api_version = 10
priority = 10000
icon_atlas = "1.xml"
icon = "1.tex"
dst_compatible = true
all_clients_require_mod = false
client_only_mod = true
server_filter_tags = {}
configuration_options = {
    {
        name = "hotkey",
        label = "启动热键",
        hover = "启动热键(shift+热键切换功能)",
        options = {
            {description = "X", data = 120},
            {description = "C", data = 99},
            {description = "V", data = 118},
            {description = "F5", data = 286},
            {description = "F6", data = 287},
            {description = "F7", data = 288},
            {description = "F8", data = 289},
            {description = "F9", data = 290},
            {description = "F10", data = 291}
        },
        default = 289
    },
    {
        name = "default",
        label = "默认工作",
        hover = "默认工作",
        options = {
            {description = "矿工", data = 1},
            {description = "农夫", data = 2},
            {description = "渔夫", data = 3},
            {description = "炸弹人", data = 4},
            {description = "铁匠", data = 5},
        },
        default = 1
    },
    {
        name = "reconnect",
        label = "掉线重连",
        hover = "掉线重连",
        options = {
            {description = "关闭", data = false},
            {description = "开启", data = true}
        },
        default = false
    },
	--[[
	{
        name = "smith__sanity_enable",
        label = "战斗-精神-启用",
        hover = "使用恢复精神的食物",
        options = {{description = "关闭", data = false}, {description = "开启", data = true}},
        default = true
    },
    {
        name = "smith_sanity_threshold",
        label = "战斗-精神-阈值",
        hover = "精神阈值(百分比)",
        options = {
            {description = "10%", data = 0.1},
            {description = "20%", data = 0.2},
            {description = "30%", data = 0.3},
            {description = "40%", data = 0.4},
            {description = "50%", data = 0.5},
            {description = "60%", data = 0.6},
            {description = "75%", data = 0.75},
            {description = "90%", data = 0.9},
            {description = "100%", data = 0x1}
        },
        default = 0.5
    },
	{
        name = "smith_sanity_food",
        label = "战斗-精神-食物",
        hover = "食物",
        options = {{description = "呆龙心", data = "dragoonheart"}, {description = "齿轮(机器人专用)", data = "gears"}},
        default = "dragoonheart"
    },]]
    {
        name = "miner_general_range",
        label = "矿工-常规-范围",
        hover = "矿工-常规-范围",
        options = {
            {description = "12", data = 12},
            {description = "24", data = 24},
            {description = "36", data = 36},
            {description = "48", data = 48},
        },
        default = 12
    },
    {
        name = "miner_pick_fossil_piece",
        label = "矿工-拾取-化石",
        hover = "矿工-拾取-化石",
        options = {
            {description = "关", data = false},
            {description = "拾取出售", data = 1},
            {description = "拾取打包", data = 2}
        },
        default = false
    },
    {
        name = "miner_pick_ore_gray",
        label = "矿工-拾取-玄铁精",
        hover = "矿工-拾取-玄铁精",
        options = {
            {description = "关", data = false},
            {description = "拾取出售", data = 1},
            {description = "拾取打包", data = 2}
        },
        default = false
    },
    {
        name = "miner_pick_ore_green",
        label = "矿工-拾取-碧灵玉",
        hover = "矿工-拾取-碧灵玉",
        options = {
            {description = "关", data = false},
            {description = "拾取出售", data = 1},
            {description = "拾取打包", data = 2}
        },
        default = false
    },
    {
        name = "miner_pick_ore_blue",
        label = "矿工-拾取-星寒陨",
        hover = "矿工-拾取-星寒陨",
        options = {
            {description = "关", data = false},
            {description = "拾取出售", data = 1},
            {description = "拾取打包", data = 2}
        },
        default = false
    },
    {
        name = "miner_pick_ore_purple",
        label = "矿工-拾取-紫髓心",
        hover = "矿工-拾取-紫髓心",
        options = {
            {description = "关", data = false},
            {description = "拾取出售", data = 1},
            {description = "拾取打包", data = 2}
        },
        default = false
    },
    {
        name = "miner_pick_ore_orange",
        label = "矿工-拾取-金曜珀",
        hover = "矿工-拾取-金曜珀",
        options = {
            {description = "关", data = false},
            {description = "拾取出售", data = 1},
            {description = "拾取打包", data = 2}
        },
        default = false
    },
    {
        name = "miner_pick_flame_soul",
        label = "矿工-拾取-赤炎心魄",
        hover = "矿工-拾取-赤炎心魄",
        options = {
            {description = "关", data = false},
            {description = "拾取出售", data = 1},
            {description = "拾取打包", data = 2}
        },
        default = false
    },
    {
        name = "farmer_general_range",
        label = "农夫-常规-范围",
        hover = "农夫-常规-范围",
        options = {
            {description = "4", data = 4},
            {description = "6", data = 6},
            {description = "8", data = 8},
            {description = "10", data = 10},
            {description = "12", data = 12},
            {description = "14", data = 14},
            {description = "16", data = 16},
            {description = "18", data = 18},
            {description = "20", data = 20}
        },
        default = 6
    },
    {
        name = "farmer_pick_grass",
        label = "农夫-收集-草",
        hover = "农夫-收集-草",
        options = {
            {description = "关", data = false},
            {description = "开", data = true},
        },
        default = false
    },
    {
        name = "farmer_pick_sapling",
        label = "农夫-收集-树枝",
        hover = "农夫-收集-树枝",
        options = {
            {description = "关", data = false},
            {description = "开", data = true},
        },
        default = false
    },
	{
        name = "farmer_pick_monkeytail",
        label = "农夫-收集-猴尾草",
        hover = "农夫-收集-猴尾草",
        options = {
            {description = "关", data = false},
            {description = "开", data = true},
        },
        default = false
    },
    {
        name = "farmer_pick_reeds",
        label = "农夫-收集-芦苇",
        hover = "农夫-收集-芦苇",
        options = {
            {description = "关", data = false},
            {description = "开", data = true},
        },
        default = false
    },
	{name = "", label = "锻造-详细设置", options = { {description = "", data = ""}, }, default = "", },
    {
        name = "smith_general_range",
        label = "铁匠-常规-范围",
        hover = "",
        options = {
            {description = "2*2", data = 4},
            {description = "4*4", data = 8},
            {description = "6*6", data = 12},
            {description = "8*8", data = 16},
            {description = "10*10", data = 20},
            {description = "12*12", data = 24},
            {description = "14*14", data = 28},
            {description = "16*16", data = 32},
        },
        default = 18
    },
    {
        name = "smith_general_drop",
        label = "铁匠-常规-丢弃启灵心",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
	{
        name = "smith_general_buy",
        label = "铁匠-常规-自动购买分解符",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
	{name = "", label = "蓝近锻造-详细设置", options = { {description = "", data = ""}, }, default = "", },
    {
        name = "smith_blue_enable",
        label = "铁匠-蓝近-锻造",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_blue_ore",
        label = "铁匠-蓝近-石头",
        hover = "",
        options = {
            {description = "星寒陨", data = "ore_blue" },
            {description = "紫髓心", data = "ore_purple" },
            {description = "金曜珀", data = "ore_orange" }
        },
        default = "ore_blue"
    },
    {
        name = "smith_blue_flamesoul",
        label = "铁匠-蓝近-红瓶",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_blue_items_nilin",
        label = "铁匠-蓝近-装备-逆鳞",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_items_anri",
        label = "铁匠-蓝近-装备-暗日",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_items_miejitufu",
        label = "铁匠-蓝近-装备-灭寂屠斧",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_items_pohundao",
        label = "铁匠-蓝近-装备-破魂刀",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_items_huamei",
        label = "铁匠-蓝近-装备-画眉",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_skills_fengbao",
        label = "铁匠-蓝近-特性-风暴",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_skills_yunxing",
        label = "铁匠-蓝近-特性-陨星",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_skills_chushou",
        label = "铁匠-蓝近-特性-触手",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_skills_chongneng",
        label = "铁匠-蓝近-特性-充能",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_skills_tujin",
        label = "铁匠-蓝近-特性-突进",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_skills_qiangli",
        label = "铁匠-蓝近-特性-强力",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_skills_suijia",
        label = "铁匠-蓝近-特性-碎甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_skills_pili",
        label = "铁匠-蓝近-特性-霹雳",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_skills_xunji",
        label = "铁匠-蓝近-特性-迅疾",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_tags_upgrade",
        label = "铁匠-蓝近-标签-伪属性",
        hover = "",
        options = {
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
    {
        name = "smith_blue_tags_dual",
        label = "铁匠-蓝近-标签-双特",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_tags_maximun",
        label = "铁匠-蓝近-标签-满基础",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_tags_unlimit",
        label = "铁匠-蓝近-标签-无级别",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_tags_nodur",
        label = "铁匠-蓝近-标签-无次数",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{
        name = "smith_blue_tags_nodur_1",
        label = "铁匠-蓝近-标签-锻造剩余5次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{name = "", label = "蓝远锻造-详细设置", options = { {description = "", data = ""}, }, default = "", },
    {
        name = "smith_blue_range_enable",
        label = "铁匠-蓝远-锻造",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_blue_range_ore",
        label = "铁匠-蓝远-石头",
        hover = "",
        options = {
            {description = "星寒陨", data = "ore_blue" },
            {description = "紫髓心", data = "ore_purple" },
            {description = "金曜珀", data = "ore_orange" }
        },
        default = "ore_blue"
    },
    {
        name = "smith_blue_range_flamesoul",
        label = "铁匠-蓝远-红瓶",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_blue_range_items_liming",
        label = "铁匠-蓝远-装备-黎明",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_items_xingchen",
        label = "铁匠-蓝远-装备-星辰",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_items_hua",
        label = "铁匠-蓝远-装备-花",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_skills_fengbao",
        label = "铁匠-蓝远-特性-风暴",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_skills_yunxing",
        label = "铁匠-蓝远-特性-陨星",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_skills_chushou",
        label = "铁匠-蓝远-特性-触手",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_skills_chongneng",
        label = "铁匠-蓝远-特性-充能",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_skills_qubi",
        label = "铁匠-蓝远-特性-趋避",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_skills_qiangli",
        label = "铁匠-蓝远-特性-强力",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_skills_suijia",
        label = "铁匠-蓝远-特性-碎甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_skills_pili",
        label = "铁匠-蓝远-特性-霹雳",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_skills_xunji",
        label = "铁匠-蓝远-特性-迅疾",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_tags_upgrade",
        label = "铁匠-蓝远-标签-伪属性",
        hover = "",
        options = {
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
    {
        name = "smith_blue_range_tags_dual",
        label = "铁匠-蓝远-标签-双特",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_tags_maximun",
        label = "铁匠-蓝远-标签-满基础",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_tags_unlimit",
        label = "铁匠-蓝远-标签-无级别",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_blue_range_tags_nodur",
        label = "铁匠-蓝远-标签-无次数",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{
        name = "smith_blue_range_tags_nodur_1",
        label = "铁匠-蓝远-标签-锻造剩余5次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{name = "", label = "紫近锻造-详细设置", options = { {description = "", data = ""}, }, default = "", },
    {
        name = "smith_purple_enable",
        label = "铁匠-紫近-锻造",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_purple_ore",
        label = "铁匠-紫近-石头",
        hover = "",
        options = {
            {description = "紫髓心", data = "ore_purple" },
            {description = "金曜珀", data = "ore_orange" }
        },
        default = "ore_purple"
    },
    {
        name = "smith_purple_flamesoul",
        label = "铁匠-紫近-红瓶",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_purple_items_caijue",
        label = "铁匠-紫近-装备-裁决",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_items_xuezou",
        label = "铁匠-紫近-装备-雪走",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_items_xuansong",
        label = "铁匠-紫近-装备-玄嵩",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_items_taihua",
        label = "铁匠-紫近-装备-太华",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_items_youheng",
        label = "铁匠-紫近-装备-幽衡",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_items_daizong",
        label = "铁匠-紫近-装备-岱宗",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_items_shenpan",
        label = "铁匠-紫近-装备-审判",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_items_panyexueyin",
        label = "铁匠-紫近-装备-潘夜血饮",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_items_guiyan",
        label = "铁匠-紫近-装备-鬼炎",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_skills_tujin",
        label = "铁匠-紫近-特性-突进",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_skills_qiangli",
        label = "铁匠-紫近-特性-强力",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_skills_suijia",
        label = "铁匠-紫近-特性-碎甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_skills_pili",
        label = "铁匠-紫近-特性-霹雳",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_skills_xunji",
        label = "铁匠-紫近-特性-迅疾",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_skills_shixue",
        label = "铁匠-紫近-特性-嗜血",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
	{
        name = "smith_purple_skills_lianji",
        label = "铁匠-紫近-特性-连击",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_skills_baolie",
        label = "铁匠-紫近-特性-爆裂",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_skills_ranxue",
        label = "铁匠-紫近-特性-燃血",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_skills_zhentui",
        label = "铁匠-紫近-特性-震退",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_tags_upgrade",
        label = "铁匠-紫近-标签-伪属性",
        hover = "",
        options = {
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
    {
        name = "smith_purple_tags_dual",
        label = "铁匠-紫近-标签-双特",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_tags_maximun",
        label = "铁匠-紫近-标签-满基础",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_tags_unlimit",
        label = "铁匠-紫近-标签-无级别",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_tags_nodur",
        label = "铁匠-紫近-标签-无次数",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{
        name = "smith_purple_tags_nodur_1",
        label = "铁匠-紫远-标签-锻造剩余5次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{name = "", label = "紫远锻造-详细设置", options = { {description = "", data = ""}, }, default = "", },
    {
        name = "smith_purple_range_enable",
        label = "铁匠-紫远-锻造",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_purple_range_ore",
        label = "铁匠-紫远-石头",
        hover = "",
        options = {
            {description = "紫髓心", data = "ore_purple" },
            {description = "金曜珀", data = "ore_orange" }
        },
        default = "ore_purple"
    },
    {
        name = "smith_purple_range_flamesoul",
        label = "铁匠-紫远-红瓶",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_purple_range_items_riyao",
        label = "铁匠-紫远-装备-日曜",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_items_feiheng",
        label = "铁匠-紫远-装备-飞衡",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_items_hanbingquanzhang",
        label = "铁匠-紫远-装备-寒冰权杖",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_skills_qubi",
        label = "铁匠-紫远-特性-趋避",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_skills_qiangli",
        label = "铁匠-紫远-特性-强力",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_skills_suijia",
        label = "铁匠-紫远-特性-碎甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_skills_pili",
        label = "铁匠-紫远-特性-霹雳",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_skills_xunji",
        label = "铁匠-紫远-特性-迅疾",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_skills_jufeng",
        label = "铁匠-紫远-特性-飓风",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_skills_shixue",
        label = "铁匠-紫远-特性-嗜血",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
	{
        name = "smith_purple_range_skills_lianji",
        label = "铁匠-紫远-特性-连击·",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_skills_baolie",
        label = "铁匠-紫远-特性-爆裂",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_skills_ranxue",
        label = "铁匠-紫远-特性-燃血",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_skills_zhentui",
        label = "铁匠-紫远-特性-震退",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_tags_upgrade",
        label = "铁匠-紫远-标签-伪属性",
        hover = "",
        options = {
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
    {
        name = "smith_purple_range_tags_dual",
        label = "铁匠-紫远-标签-双特",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_tags_maximun",
        label = "铁匠-紫远-标签-满基础",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_tags_unlimit",
        label = "铁匠-紫远-标签-无级别",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_purple_range_tags_nodur",
        label = "铁匠-紫远-标签-无次数",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{
        name = "smith_purple_range_tags_nodur_1",
        label = "铁匠-紫远-标签-锻造剩余5次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{name = "", label = "橙近锻造-详细设置", options = { {description = "", data = ""}, }, default = "", },
    {
        name = "smith_orange_enable",
        label = "铁匠-橙近-锻造",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_orange_ore",
        label = "铁匠-橙近-石头",
        hover = "",
        options = {
            {description = "金曜珀", data = "ore_orange" }
        },
        default = "ore_orange"
    },
    {
        name = "smith_orange_flamesoul",
        label = "铁匠-橙近-红瓶",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_orange_items_bihaitianwang",
        label = "铁匠-橙近-装备-碧海天王",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_items_chimingtiandi",
        label = "铁匠-橙近-装备-赤明天帝",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_items_mingyue",
        label = "铁匠-橙近-装备-冥月",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_items_yaoyangshengzun",
        label = "铁匠-橙近-装备-耀阳圣尊",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_items_chiri",
        label = "铁匠-橙近-装备-赤日",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_items_ziyueshengjun",
        label = "铁匠-橙近-装备-紫月圣君",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_items_shuanglengjiuzhou",
        label = "铁匠-橙近-装备-霜冷九州",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_items_hongying",
        label = "铁匠-橙近-装备-红樱",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_items_yangmie",
        label = "铁匠-橙近-装备-羊咩！",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_skills_shixue",
        label = "铁匠-橙近-特性-嗜血",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
	{
        name = "smith_orange_skills_lianji",
        label = "铁匠-橙近-特性-连击·",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_skills_baolie",
        label = "铁匠-橙近-特性-爆裂",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_skills_ranxue",
        label = "铁匠-橙近-特性-燃血",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_skills_zhentui",
        label = "铁匠-橙近-特性-震退",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_skills_chuanjia",
        label = "铁匠-橙近-特性-穿甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_skills_xushi",
        label = "铁匠-橙近-特性-蓄势",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_skills_kuangbao",
        label = "铁匠-橙近-特性-狂暴",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_skills_baoji",
        label = "铁匠-橙近-特性-暴击",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_skills_yunjian",
        label = "铁匠-橙近-特性-云箭",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_skills_pojun",
        label = "铁匠-橙近-特性-破军",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_tags_upgrade",
        label = "铁匠-橙近-标签-伪属性",
        hover = "",
        options = {
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
    {
        name = "smith_orange_tags_dual",
        label = "铁匠-橙近-标签-双特",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_tags_maximun",
        label = "铁匠-橙近-标签-满基础",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_tags_unlimit",
        label = "铁匠-橙近-标签-无级别",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_tags_nodur",
        label = "铁匠-橙近-标签-无次数",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{
        name = "smith_orange_tags_nodur_1",
        label = "铁匠-橙近-标签-锻造剩余5次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
	--[[{
        name = "smith_orange_tags_nodur_2",
        label = "铁匠-橙近-标签-锻造剩余10次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },]]
	{name = "", label = "橙远锻造-详细设置", options = { {description = "", data = ""}, }, default = "", },
    {
        name = "smith_orange_range_enable",
        label = "铁匠-橙远-锻造",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_orange_range_ore",
        label = "铁匠-橙远-石头",
        hover = "",
        options = {
            {description = "金曜珀", data = "ore_orange" }
        },
        default = "ore_orange"
    },
    {
        name = "smith_orange_range_flamesoul",
        label = "铁匠-橙远-红瓶",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_orange_range_items_tihu",
        label = "铁匠-橙远-装备-醍醐",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_items_yaoguang",
        label = "铁匠-橙远-装备-耀光",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_items_wumai",
        label = "铁匠-橙远-装备-雾霾",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_items_wanzun",
        label = "铁匠-橙远-装备-挽尊",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_items_hunzhang",
        label = "铁匠-橙远-装备-魂杖",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    
    {
        name = "smith_orange_range_skills_jufeng",
        label = "铁匠-橙远-特性-飓风",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_skills_shixue",
        label = "铁匠-橙远-特性-嗜血",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
	{
        name = "smith_orange_range_skills_lianji",
        label = "铁匠-橙远-特性-连击·",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_skills_baolie",
        label = "铁匠-橙远-特性-爆裂",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_skills_ranxue",
        label = "铁匠-橙远-特性-燃血",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_skills_zhentui",
        label = "铁匠-橙远-特性-震退",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_skills_chuanjia",
        label = "铁匠-橙远-特性-穿甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_skills_xushi",
        label = "铁匠-橙远-特性-蓄势",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_skills_kuangbao",
        label = "铁匠-橙远-特性-狂暴",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_skills_baoji",
        label = "铁匠-橙远-特性-暴击",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_skills_yunjian",
        label = "铁匠-橙远-特性-云箭",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_skills_pojun",
        label = "铁匠-橙远-特性-破军",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_tags_upgrade",
        label = "铁匠-橙远-标签-伪属性",
        hover = "",
        options = {
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
    {
        name = "smith_orange_range_tags_dual",
        label = "铁匠-橙远-标签-双特",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_tags_maximun",
        label = "铁匠-橙远-标签-满基础",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_tags_unlimit",
        label = "铁匠-橙远-标签-无级别",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_orange_range_tags_nodur",
        label = "铁匠-橙远-标签-无次数",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{
        name = "smith_orange_range_tags_nodur_1",
        label = "铁匠-橙远-标签-锻造剩余5次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    --[[{
        name = "smith_orange_range_tags_nodur_2",
        label = "铁匠-橙远-标签-锻造剩余10次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },]]
	{name = "", label = "盔甲锻造-详细设置", options = { {description = "", data = ""}, }, default = "", },
    {
        name = "smith_armor_enable",
        label = "铁匠-盔甲-锻造",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_armor_ore",
        label = "铁匠-盔甲-石头",
        hover = "",
        options = {
            {description = "紫髓心", data = "ore_purple" },
            {description = "金曜珀", data = "ore_orange" }
        },
        default = "ore_purple"
    },
    {
        name = "smith_armor_flamesoul",
        label = "铁匠-盔甲-红瓶",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_armor_items_jaggedarmor",
        label = "铁匠-盔甲-装备-锯齿木甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_armor_items_jaggedgrandarmor",
        label = "铁匠-盔甲-装备-豪华锯齿铠甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_armor_items_silkenarmor",
        label = "铁匠-盔甲-装备-丝绸木甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_armor_items_silkengrandarmor",
        label = "铁匠-盔甲-装备-豪华丝带铠甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_armor_items_splintmail",
        label = "铁匠-盔甲-装备-锁石甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_armor_items_whisperinggrandarmor",
        label = "铁匠-盔甲-装备-豪华低语铠甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_armor_items_steadfastarmor",
        label = "铁匠-盔甲-装备-磐石铠甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_armor_items_steadfastgrandarmor",
        label = "铁匠-盔甲-装备-豪华坚定铠甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_diyu",
        label = "铁匠-盔甲-特性-抵御",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_shengguang",
        label = "铁匠-盔甲-特性-圣光",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_pipan",
        label = "铁匠-盔甲-特性-批判",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_qiangli",
        label = "铁匠-盔甲-特性-强力",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_xunji",
        label = "铁匠-盔甲-特性-迅疾",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_hudun",
        label = "铁匠-盔甲-特性-护盾",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_jianshou",
        label = "铁匠-盔甲-特性-坚守",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_ziyu",
        label = "铁匠-盔甲-特性-自愈",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_jingji",
        label = "铁匠-盔甲-特性-荆棘",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_zhentui",
        label = "铁匠-盔甲-特性-震退",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_wushuang",
        label = "铁匠-盔甲-特性-无双",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_xinsheng",
        label = "铁匠-盔甲-特性-新生",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_shenyou",
        label = "铁匠-盔甲-特性-神佑",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_miankong",
        label = "铁匠-盔甲-特性-免控",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_skills_zibi",
        label = "铁匠-盔甲-特性-自闭",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
	{
        name = "smith_armor_skills_riyan",
        label = "铁匠-盔甲-特性-日炎",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_armor_tags_dual",
        label = "铁匠-盔甲-标签-双特",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
	{
        name = "smith_armor_tags_unlimit",
        label = "铁匠-盔甲-标签-无级别",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_armor_tags_nodur",
        label = "铁匠-盔甲-标签-无次数",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{
        name = "smith_armor_tags_nodur_1",
        label = "铁匠-盔甲-标签-锻造剩余5次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{name = "", label = "稀有橙近-详细设置", options = { {description = "", data = ""}, }, default = "", },
	{
        name = "smith_special_orange_enable",
        label = "铁匠-稀有橙近-锻造",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_special_orange_ore",
        label = "铁匠-稀有橙近-石头",
        hover = "",
        options = {
            {description = "紫髓心", data = "ore_purple" },
            {description = "金曜珀", data = "ore_orange" }
        },
        default = "ore_orange"
    },
    {
        name = "smith_special_orange_flamesoul",
        label = "铁匠-稀有橙近-红瓶",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_special_orange_items_tianjie",
        label = "铁匠-稀有橙近-装备-天劫",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_items_chenxin",
        label = "铁匠-稀有橙近-装备-尘心",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_items_yihuang",
        label = "铁匠-稀有橙近-装备-燚煌",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
	{
        name = "smith_special_orange_items_tianzhao",
        label = "铁匠-稀有橙近-装备-天照",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
	{
        name = "smith_special_orange_skills_chuanjia",
        label = "铁匠-稀有橙近-特性-穿甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_skills_xushi",
        label = "铁匠-稀有橙近-特性-蓄势",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_skills_kuangbao",
        label = "铁匠-稀有橙近-特性-狂暴",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_skills_baoji",
        label = "铁匠-稀有橙近-特性-暴击",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_skills_yunjian",
        label = "铁匠-稀有橙近-特性-云箭",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_skills_pojun",
        label = "铁匠-稀有橙近-特性-破军",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_tags_dual",
        label = "铁匠-稀有橙近-标签-双特",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_tags_maximun",
        label = "铁匠-稀有橙近-标签-满基础",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_tags_unlimit",
        label = "铁匠-稀有橙近-标签-无级别",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_tags_nodur",
        label = "铁匠-稀有橙近-标签-无次数",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{
        name = "smith_special_orange_tags_nodur_1",
        label = "铁匠-稀有橙近-标签-锻造剩余5次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{name = "", label = "稀有橙远-详细设置", options = { {description = "", data = ""}, }, default = "", },
	{
        name = "smith_special_orange_range_enable",
        label = "铁匠-稀有橙远-锻造",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_special_orange_range_ore",
        label = "铁匠-稀有橙远-石头",
        hover = "",
        options = {
            {description = "金曜珀", data = "ore_orange" }
        },
        default = "ore_orange"
    },
    {
        name = "smith_special_orange_range_flamesoul",
        label = "铁匠-稀有橙远-红瓶",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_special_orange_range_items_kongqueling",
        label = "铁匠-稀有橙远-装备-孔雀翎",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_range_items_youhuang",
        label = "铁匠-稀有橙远-装备-幽篁",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
	{
        name = "smith_special_orange_range_items_yuedu",
        label = "铁匠-稀有橙远-装备-月渎",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
	{
        name = "smith_special_orange_range_skills_chuanjia",
        label = "铁匠-稀有橙远-特性-穿甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_range_skills_xushi",
        label = "铁匠-稀有橙远-特性-蓄势",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_range_skills_kuangbao",
        label = "铁匠-稀有橙远-特性-狂暴",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_range_skills_baoji",
        label = "铁匠-稀有橙远-特性-暴击",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_range_skills_yunjian",
        label = "铁匠-稀有橙远-特性-云箭",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_range_skills_pojun",
        label = "铁匠-稀有橙远-特性-破军",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_range_tags_dual",
        label = "铁匠-稀有橙远-标签-双特",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_range_tags_maximun",
        label = "铁匠-稀有橙远-标签-满基础",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_range_tags_unlimit",
        label = "铁匠-稀有橙远-标签-无级别",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_special_orange_range_tags_nodur",
        label = "铁匠-稀有橙远-标签-无次数",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{
        name = "smith_special_orange_range_tags_nodur_1",
        label = "铁匠-稀有橙远-标签-锻造剩余5次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{name = "", label = "毕业甲-详细设置", options = { {description = "", data = ""}, }, default = "", },
	{
        name = "smith_special_armor_enable",
        label = "铁匠-毕业甲-锻造",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_special_armor_ore",
        label = "铁匠-毕业甲-石头",
        hover = "",
        options = {
            {description = "紫髓心", data = "ore_purple" },
            {description = "金曜珀", data = "ore_orange" }
        },
        default = "ore_purple"
    },
    {
        name = "smith_special_armor_flamesoul",
        label = "铁匠-毕业甲-红瓶",
        hover = "",
        options = {
            {description = "关闭", data = false },
            {description = "开启", data = true }
        },
        default = false
    },
    {
        name = "smith_special_armor_items_steadfastgrandarmor",
        label = "铁匠-毕业甲-装备-豪华坚定铠甲",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
	{
        name = "smith_apecial_armor_skills_diyu",
        label = "铁匠-毕业甲-特性-抵御",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_shengguang",
        label = "铁匠-毕业甲-特性-圣光",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_pipan",
        label = "铁匠-毕业甲-特性-批判",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_qiangli",
        label = "铁匠-毕业甲-特性-强力",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_xunji",
        label = "铁匠-毕业甲-特性-迅疾",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_hudun",
        label = "铁匠-毕业甲-特性-护盾",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_jianshou",
        label = "铁匠-毕业甲-特性-坚守",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_ziyu",
        label = "铁匠-毕业甲-特性-自愈",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_jingji",
        label = "铁匠-毕业甲-特性-荆棘",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_zhentui",
        label = "铁匠-毕业甲-特性-震退",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_wushuang",
        label = "铁匠-毕业甲-特性-无双",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_xinsheng",
        label = "铁匠-毕业甲-特性-新生",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_shenyou",
        label = "铁匠-毕业甲-特性-神佑",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_miankong",
        label = "铁匠-毕业甲-特性-免控",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_apecial_armor_skills_zibi",
        label = "铁匠-毕业甲-特性-自闭",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
	{
        name = "smith_apecial_armor_skills_riyan",
        label = "铁匠-毕业甲-特性-日炎",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "分解", data = "rs"},
            {description = "分解单特", data = "rs_s"},
            {description = "保留", data = "rf"},
            {description = "保留单特", data = "rf_s"},
            {description = "智能分解1", data = "m",hover="次数在30-11时分解单特,10次以下时遇见即分解"},
            {description = "智能分解2", data = "m_s",hover="只有10次以下时才分解"}
        },
        default = "re"
    },
    {
        name = "smith_special_armor_tags_dual",
        label = "铁匠-毕业甲-标签-双特",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
	{
        name = "smith_special_armor_tags_unlimit",
        label = "铁匠-毕业甲-标签-无级别",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "保留", data = "rf"}
        },
        default = "re"
    },
    {
        name = "smith_special_armor_tags_nodur",
        label = "铁匠-毕业甲-标签-无次数",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    },
	{
        name = "smith_special_armor_tags_nodur_1",
        label = "铁匠-毕业甲-标签-锻造剩余5次",
        hover = "",
        options = {
            {description = "重锻", data = "re"},
            {description = "融合", data = "fu"},
            {description = "分解", data = "rs"},
            {description = "保留", data = "rf"}
        },
        default = "rf"
    }
}